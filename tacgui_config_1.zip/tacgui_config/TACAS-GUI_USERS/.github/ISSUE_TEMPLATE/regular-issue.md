---
name: Regular Issue
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the system**
Ubuntu version: ... 
(use next command: lsb_release -a )
PHP version: ... 
(use next command: php -v )
TacacsGUI API version: **IMPORTANT** 
(use next command: php -r 'include "/opt/tacacsgui/web/api/constants.php"; echo APIVER . "\n";' )
Browser: [e.g. chrome, safari]

**Describe the bug**
A clear and concise description of what the bug is.
