<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
$mainUrl = 'javascript:void(0)';
 ?>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title><?php echo $subject; ?></title>

<?php require __DIR__  . '/style.php'; ?>


<script type="colorScheme" class="swatch active">
{
    "name":"Default",
    "bgBody":"ffffff",
    "link":"27A1E5",
    "color":"AAAAAA",
    "bgItem":"ffffff",
    "title":"444444"
}
</script>


</head>
<body paddingwidth="0" paddingheight="0" bgcolor="#d1d3d4"  style="padding-top: 0; padding-bottom: 0; padding-top: 0; padding-bottom: 0; background-repeat: repeat; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-font-smoothing: antialiased;" offset="0" toppadding="0" leftpadding="0">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td>
        <table width="600" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="#ffffff" style="font-family:helvetica, sans-serif;" class="MainContainer">
      <!-- =============== START HEADER =============== -->
  <tbody>
    <tr>
      <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td valign="top" width="20">&nbsp;</td>
      <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td class="movableContentContainer">
      <div class="movableContent" style="border: 0px; padding-top: 0px; position: relative;">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td height="15"></td>
    </tr>
    <tr>
      <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tbody>
            <tr>
              <td valign="top">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tbody>
                    <tr>
                      <td valign="top" width="60"><img src="cid:logo" alt="Logo" title="Logo" width="60" height="60" data-max-width="100"></td>
                      <td width="10" valign="top">&nbsp;</td>
                      <td valign="middle" style='vertical-align: middle;'>
                        <div class='contentEditableContainer contentTextEditable'>
                          <div class='contentEditable' style='text-align: left;font-weight: light; color:#555555;font-size:26;line-height: 39px;font-family: Helvetica Neue;'>
                            <h1 class='big'><a target='_blank' href="<?php echo $mainUrl; ?>/" style='color:#444444'>TACACSGUI</a></h1>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </td>
              <td valign="top" width="90" class="spechide">&nbsp;</td>
              <!-- <td valign="middle" style='vertical-align: middle;' width='150'>
                <div class='contentEditableContainer contentTextEditable'>
                  <div class='contentEditable' style='text-align: right;'>
                    <a target='_blank' href="[SHOWEMAIL]" class='link1' >Open in your browser</a>
                  </div>
                </div>
              </td> -->
            </tr>
          </tbody>
        </table>
      </td>
</tr>
<tr>
<td height='15'></td>
</tr>
<tr>
<td ><hr style='height:1px;background:#DDDDDD;border:none;'></td>
</tr>
</tbody>
</table>
  </div>
<!-- =============== END HEADER =============== -->
